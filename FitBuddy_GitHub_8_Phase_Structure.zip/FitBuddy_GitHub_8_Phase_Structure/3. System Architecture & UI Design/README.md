# 3. System Architecture & UI Design

## Objective
Design the system architecture, workflow, database flow, and user interface.

## Architecture
User Interface → FastAPI → Gemini AI → Database / Result → Jinja2

## Main Pages
- `index.html`
- `result.html`
- `all_users.html`

## Deliverables
- System Architecture
- Workflow Diagram
- UI Design
- Database Design
